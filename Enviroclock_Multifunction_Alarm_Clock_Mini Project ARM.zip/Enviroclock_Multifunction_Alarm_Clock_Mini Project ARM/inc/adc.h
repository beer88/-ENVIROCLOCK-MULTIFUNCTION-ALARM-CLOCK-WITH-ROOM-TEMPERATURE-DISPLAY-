#include "types.h"

void Init_adc(void);
void Read_LM35_Temperature(u32 chno, f32 *temperature);

