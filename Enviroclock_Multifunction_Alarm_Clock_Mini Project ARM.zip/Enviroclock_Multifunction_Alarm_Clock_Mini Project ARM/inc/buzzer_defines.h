#define BUZZER        (1 << 27)   // Buzzer at P1.27
#define STOP_BUTTON    28   // Stop button at P1.28
