#include "types.h"

void delayUS(u32);
void delayMS(u32);
void delayS(u32);

