#include "lpc214x.h"
#include "defines.h"
#include "pin_connect_block.h"

void Init_eint(void);
void eint0_isr(void) __irq;	

