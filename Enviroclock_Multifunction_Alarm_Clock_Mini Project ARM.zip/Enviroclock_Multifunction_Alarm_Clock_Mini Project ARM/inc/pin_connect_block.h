//pin_connect_block.h
#include "types.h"

void CfgPortPinFunc(u32 portNo,
	                  u32 pinNo,
                    u32 pinFunc);

